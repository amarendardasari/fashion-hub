import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { first } from 'rxjs';
import { Country } from '../../common/country';
import { State } from '../../common/state';
import { CheckoutService } from '../../services/checkout.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css',
})
export class CheckoutComponent {
  checkoutFormGroup: FormGroup;
  contries:Country[]=[];
  shippingAddresState:State[]=[];
  billingAddressState:State[]=[];
  constructor(private formBuilder: FormBuilder,
    private checkoutService:CheckoutService
  ) {}

  ngOnInit() {
    this.checkoutFormGroup = this.formBuilder.group({
      customer: this.formBuilder.group({
        firstName: [''],
        lastName: [''],
        email: [''],
        mobile: [''],
      }),
      shippingAddress: this.formBuilder.group({
        street: [''],
        city: [''],
        state: [''],
        country: [''],
        zipCode: [''],
      }),
      billingAddress: this.formBuilder.group({
        street: [''],
        city: [''],
        state: [''],
        country: [''],
        zipCode: [''],
      }),
    });

    //populate contries
    this.checkoutService.getCountries().subscribe((data)=>{
      this.contries=data;
      console.log(data);
    });
  }
  copyShippingAddress(event: any) {
    if (event.target.checked) {
      // reading shippingAddress from data
      const shippingAddressData =
        this.checkoutFormGroup?.get('shippingAddress')?.value;

      // assign shippingAddress form data to billingAddress form data
      this.checkoutFormGroup?.controls?.['billingAddress'].setValue(
        shippingAddressData
      );
    } else {
      this.checkoutFormGroup.controls?.['billingAddress'].reset();
    }
  }
  onSubmit() {
    console.log(this.checkoutFormGroup?.get('customer')?.value);
    console.log(this.checkoutFormGroup?.get('shippingAddress')?.value);
    console.log(this.checkoutFormGroup?.get('billingAddress')?.value);
  }
}